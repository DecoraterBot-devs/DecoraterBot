# coding=utf-8
"""
The MIT License (MIT)

Copyright (c) 2016 AraHaan

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
"""
import asyncio
"""
sasync
~~~~~~~~~~~~~~~~~~~

sasync for handling most asyncio stuff.
Also helps return the right "future" based on
version of python and asyncio.

:copyright: (c) 2016 Decorater
:license: MIT, see LICENSE for more details.

"""
__title__ = 'sasync'
__author__ = 'Decorater'
__license__ = 'MIT'
__copyright__ = 'Copyright 2016 Decorater'
__version__ = '0.0.1'
__build__ = 0x000001

__all__ = ['__title__', '__author__', '__license__',
           '__copyright__', '__version__', '__build__']


def export(defn):
    globals()[defn.__name__] = defn
    __all__.append(defn.__name__)
    return defn


@export
def iscoroutinefunction(coro):
    return asyncio.iscoroutinefunction(coro)


@export
def coroutine(coro):
    return asyncio.coroutine(coro)


@export
def async(coro):
    """
        shorthand for asyncio.coroutine.
    """
    if not iscoroutinefunction(coro):
        coro = coroutine(coro)
    return coro

# event loops.


@export
class Event(asyncio.Event):
    def __init__(self, *args, **kwargs):
        super(Event, self).__init__(*args, **kwargs)


@export
def get_event_loop():
    """
    Gets event loop from asyncio.

    Unlike asyncio which does not check if the event loop is closed from within their get_event_loop mine does and
    if it is closed it creates a new event loop to help simplify user code.
    :return: Event loop.
    """
    loop = asyncio.get_event_loop()
    if loop.is_closed():
        loop = new_event_loop()
    return loop


@export
def new_event_loop():
    """
    Creates a new event loop.
    :return: Event loop.
    """
    return asyncio.new_event_loop()

# Tasks


@export
class Task(asyncio.Task):
    def __init__(self, *args, **kwargs):
        super(Task, self).__init__(*args, **kwargs)


@export
def gather(*args, **kwargs):
    return asyncio.gather(*args, **kwargs)


@export
@async
def wait_for(*args, **kwargs):
    ret =  yield from asyncio.wait_for(*args, **kwargs)
    return ret


@export
@async
def wait(*args, **kwargs):
    ret = yield from asyncio.wait(*args, **kwargs)
    return ret

# lock part of Tasks?


@export
class Lock(asyncio.Lock):
    def __init__(self, *args, **kwargs):
        super(Lock, self).__init__(*args, **kwargs)


@export
class Queue(asyncio.Queue):
    def __init__(self, *args, **kwargs):
        super(Queue, self).__init__(*args, **kwargs)

# Future


@export
class Future(asyncio.Future):
    def __init__(self, *args, **kwargs):
        # bind all members from asyncio.Future
        super(Future, self).__init__(*args, **kwargs)

# Sleep


@export
@async
def sleep(value):
    ret = yield from asyncio.sleep(value)
    return ret


@export
def get_future():
    """
    Gets an asyncio future and returns it.

    For Python 3.4 this returns "asyncio.async" but for 
    Python 3.5 this returns "asyncio.ensure_future".
    """
    return getattr(asyncio, 'ensure_future', asyncio.async)
